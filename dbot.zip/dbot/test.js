const z = require('tiktok-scraper-without-watermark')

z.ssstik('vt.tiktok.com/ZSJPnVLYf').then(n => console.log(n))